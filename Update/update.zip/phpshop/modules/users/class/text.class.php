<?php

class PHPShopText {

    function b($string) {
        return '<b>'.$string.'</b>';
    }

    function notice($string){
        return '<font color="red">'.$string.'</font>';
    }

}

?>