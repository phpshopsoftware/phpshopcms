
ALTER TABLE `phpshop_modules_returncall_system` ADD `windows` enum('0','1') NOT NULL default '0';
ALTER TABLE `phpshop_modules_returncall_system` CHANGE `version``version` FLOAT(2) DEFAULT '1.0' NOT NULL;

