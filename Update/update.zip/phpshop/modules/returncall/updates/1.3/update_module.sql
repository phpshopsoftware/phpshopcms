
ALTER TABLE `phpshop_modules_returncall_system` ADD `captcha_enabled` enum('1','2') NOT NULL default '1';
