
ALTER TABLE `phpshop_modules_chat_jurnal` ADD `avatar` varchar(255) NOT NULL default '';
